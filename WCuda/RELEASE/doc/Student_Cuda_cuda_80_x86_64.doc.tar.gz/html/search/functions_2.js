var searchData=
[
  ['get_5fn0',['get_n0',['../d3/d96/classMontecarlo.html#af1c53b097f578b86fc173448b48fd84d',1,'Montecarlo']]],
  ['get_5fpi',['get_pi',['../d3/d96/classMontecarlo.html#ae841aef41958eb4210707d3a17f01203',1,'Montecarlo']]],
  ['getslice',['getSlice',['../de/d70/classSliceMath.html#a7826205a53404da0d58ddf2e35063e29',1,'SliceMath']]]
];
