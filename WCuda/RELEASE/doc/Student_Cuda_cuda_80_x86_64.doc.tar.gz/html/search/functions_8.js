var searchData=
[
  ['slice',['slice',['../d4/df3/mainCore_8cpp.html#afac62ecebf74b761db4892d1425dbf51',1,'mainCore.cpp']]],
  ['slice_5fadvanced',['slice_advanced',['../d4/df3/mainCore_8cpp.html#ab28356903970e33870e125970bf4cdfa',1,'mainCore.cpp']]]
];
