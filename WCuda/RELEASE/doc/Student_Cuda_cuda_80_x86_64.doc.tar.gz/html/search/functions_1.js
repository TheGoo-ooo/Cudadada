var searchData=
[
  ['createv1',['createV1',['../d6/d46/classVectorTools.html#a1c00477c0df9a27389e4528e854336e0',1,'VectorTools::createV1()'],['../d6/d4a/classSliceTools.html#ab55499c49d10de3626b948cf6e2a2658',1,'SliceTools::createV1()']]],
  ['createv2',['createV2',['../d6/d46/classVectorTools.html#ab734272c54719be8942ccea4c9833141',1,'VectorTools::createV2()'],['../d6/d4a/classSliceTools.html#a216e85529f689067bb6399191d088677',1,'SliceTools::createV2()']]]
];
